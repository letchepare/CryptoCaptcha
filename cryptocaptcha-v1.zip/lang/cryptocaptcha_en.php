<?php
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'annuler' => 'Cancel',

	// B
	'bouton_supprimer' => 'Delete',

	// E
	
	'explication_exec_clesite' => 'Public key delivred by the captcha owner (google or coinhive) wich identify your website.',
    'explication_exec_cleprive' => 'Secret key given by the captcha owner (google or coinhive) ',

	

	// L
	'label_exec_cleprive' => 'Write your secret key',
	'label_exec_clesite' => 'Write your website key',
	'legend_editer_cleprive' => 'Change your secret key',
	'legend_editer_clesite' => 'Change your website key',
	'legend_radio_google' => 'Google',
	'legend_radio_coinhive' => 'Coinhive',
	'legend_choisir_captcha' => 'Choose the captcha you wan t to use',

	// T
	'titre_config_cryptocaptcha' => 'Configure cryptocaptcha',
	'titre_cryptocaptcha' => 'CryptoCaptcha',

	// U
	'update_impossible' => 'update failed',

	// V
	'veuillez_patienter' => 'it will take a moment...'
);
